$ErrorActionPreference = 'Stop'
$outDir = Join-Path $PSScriptRoot '..\icons'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

Add-Type -AssemblyName System.Drawing

function New-LocatorIcon {
    param([int]$Size, [string]$Path)

    $bmp = New-Object System.Drawing.Bitmap $Size, $Size
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.Clear([System.Drawing.Color]::FromArgb(255, 15, 23, 42))

    $brush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 37, 99, 235))
    $margin = [Math]::Max(2, [int]($Size * 0.15))
    $g.FillEllipse($brush, $margin, $margin, $Size - 2 * $margin, $Size - 2 * $margin)

    $pen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(255, 226, 232, 240)), ([Math]::Max(1, $Size / 16))
    $g.DrawEllipse($pen, $margin, $margin, $Size - 2 * $margin, $Size - 2 * $margin)

    $inner = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 124, 58, 237))
    $innerMargin = [Math]::Max(4, [int]($Size * 0.32))
    $g.FillEllipse($inner, $innerMargin, $innerMargin, $Size - 2 * $innerMargin, $Size - 2 * $innerMargin)

    $bmp.Save($Path, [System.Drawing.Imaging.ImageFormat]::Png)

    $g.Dispose()
    $bmp.Dispose()
}

foreach ($size in @(16, 48, 128)) {
    $path = Join-Path $outDir "icon$size.png"
    New-LocatorIcon -Size $size -Path $path
    Write-Output "Created $path"
}
