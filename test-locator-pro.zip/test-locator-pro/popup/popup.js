import { loadSettings, saveSettings, getFrameworkOptions, getPriorityOptions } from '../src/shared/settings.js';
import { clearFingerprintStore, getFingerprintStats } from '../src/lib/dedup.js';

const PHASE_LABELS = {
  preparing: 'Preparing',
  page: 'Scanning page',
  iframe: 'Scanning iframes',
  popups: 'Scanning popups',
  hidden_modal: 'Hidden modals',
  dedup: 'Deduplicating',
  complete: 'Complete',
  error: 'Error'
};

const els = {
  framework: document.getElementById('framework'),
  className: document.getElementById('className'),
  includeContainers: document.getElementById('includeContainers'),
  includeNested: document.getElementById('includeNested'),
  includeHidden: document.getElementById('includeHidden'),
  autoOpenPopups: document.getElementById('autoOpenPopups'),
  respectGlobalStore: document.getElementById('respectGlobalStore'),
  priorityList: document.getElementById('priorityList'),
  scanBtn: document.getElementById('scanBtn'),
  openPanelBtn: document.getElementById('openPanelBtn'),
  clearStoreBtn: document.getElementById('clearStoreBtn'),
  status: document.getElementById('status'),
  progressSection: document.getElementById('progressSection'),
  progressPhase: document.getElementById('progressPhase'),
  progressPercent: document.getElementById('progressPercent'),
  progressBar: document.getElementById('progressBar'),
  progressStats: document.getElementById('progressStats'),
  progressCurrent: document.getElementById('progressCurrent')
};

let currentSettings = await loadSettings();
let dragItem = null;

init();

async function init() {
  renderFrameworks();
  renderPriorityList(currentSettings.priority);
  applySettingsToForm(currentSettings);
  await updateStoreStats();

  els.scanBtn.addEventListener('click', onScan);
  els.openPanelBtn.addEventListener('click', onOpenPanel);
  els.clearStoreBtn.addEventListener('click', onClearStore);

  [
    els.framework,
    els.className,
    els.includeContainers,
    els.includeNested,
    els.includeHidden,
    els.autoOpenPopups,
    els.respectGlobalStore
  ].forEach((el) => el.addEventListener('change', onSettingsChanged));

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.scanProgress?.newValue) {
      renderProgress(changes.scanProgress.newValue);
    }
  });
}

function renderFrameworks() {
  els.framework.innerHTML = getFrameworkOptions()
    .map((fw) => `<option value="${fw.id}">${fw.label}</option>`)
    .join('');
}

function renderPriorityList(priority) {
  const labels = Object.fromEntries(getPriorityOptions().map((o) => [o.key, o.label]));
  els.priorityList.innerHTML = priority
    .map(
      (key) => `
      <li draggable="true" data-key="${key}">
        <span>::</span>
        <span>${labels[key] || key}</span>
      </li>`
    )
    .join('');

  els.priorityList.querySelectorAll('li').forEach((item) => {
    item.addEventListener('dragstart', () => {
      dragItem = item;
      item.classList.add('dragging');
    });
    item.addEventListener('dragend', () => {
      item.classList.remove('dragging');
      dragItem = null;
      onSettingsChanged();
    });
    item.addEventListener('dragover', (e) => {
      e.preventDefault();
      if (!dragItem || dragItem === item) return;
      const rect = item.getBoundingClientRect();
      const next = e.clientY > rect.top + rect.height / 2;
      els.priorityList.insertBefore(dragItem, next ? item.nextSibling : item);
    });
  });
}

function applySettingsToForm(settings) {
  els.framework.value = settings.frameworkId;
  els.className.value = settings.className;
  els.includeContainers.checked = settings.includeContainers;
  els.includeNested.checked = settings.includeNested;
  els.includeHidden.checked = settings.includeHidden;
  els.autoOpenPopups.checked = settings.autoOpenPopups;
  els.respectGlobalStore.checked = settings.respectGlobalStore;
}

function readSettingsFromForm() {
  return {
    frameworkId: els.framework.value,
    className: els.className.value.trim() || 'PageLocators',
    includeContainers: els.includeContainers.checked,
    includeNested: els.includeNested.checked,
    includeHidden: els.includeHidden.checked,
    autoOpenPopups: els.autoOpenPopups.checked,
    respectGlobalStore: els.respectGlobalStore.checked,
    priority: [...els.priorityList.querySelectorAll('li')].map((li) => li.dataset.key)
  };
}

async function onSettingsChanged() {
  currentSettings = readSettingsFromForm();
  await saveSettings(currentSettings);
}

function setStatus(text, isError = false) {
  els.status.textContent = text;
  els.status.classList.toggle('error', isError);
}

function showProgress(show) {
  els.progressSection.classList.toggle('hidden', !show);
}

function renderProgress(progress) {
  if (!progress) return;

  showProgress(true);

  const phase = PHASE_LABELS[progress.phase] || progress.phase || 'Scanning';
  const percent = progress.percent ?? 0;

  els.progressPhase.textContent = phase;
  els.progressPercent.textContent = `${percent}%`;
  els.progressBar.style.width = `${percent}%`;

  const eta = progress.etaSeconds == null
    ? 'ETA —'
    : progress.etaSeconds <= 0
      ? 'ETA <1s'
      : `ETA ~${progress.etaSeconds}s`;

  const processed = progress.processed ?? 0;
  const total = progress.total ?? 0;
  const captured = progress.captured ?? 0;
  const skipped = progress.skipped ?? 0;

  els.progressStats.textContent = `${processed}/${total} processed · ${captured} captured · ${skipped} skipped · ${eta}`;

  if (progress.currentName) {
    els.progressCurrent.textContent = `Capturing: ${progress.currentName}`;
  } else if (progress.detail) {
    els.progressCurrent.textContent = progress.detail;
  }

  if (progress.phase === 'complete') {
    els.progressBar.style.background = '#16a34a';
    showProgress(true);
  }

  if (progress.phase === 'error') {
    els.progressBar.style.background = '#dc2626';
  }
}

async function onScan() {
  await onSettingsChanged();
  setStatus('');
  showProgress(true);
  renderProgress({ phase: 'preparing', percent: 0, detail: 'Starting scan… watch the page for highlights.' });
  els.scanBtn.disabled = true;
  els.scanBtn.textContent = 'Scanning…';

  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab?.id) {
    setStatus('No active tab found. Click the webpage first, then open the extension.', true);
    els.scanBtn.disabled = false;
    els.scanBtn.textContent = 'Scan Page';
    return;
  }

  if (tab?.id) {
    try {
      await chrome.sidePanel.open({ tabId: tab.id });
    } catch {
      // side panel may be unavailable
    }
  }

  try {
    const response = await chrome.runtime.sendMessage({
      type: 'SCAN_ACTIVE_TAB',
      tabId: tab.id,
      frameworkId: currentSettings.frameworkId,
      className: currentSettings.className,
      options: currentSettings
    });

    if (!response?.ok) {
      throw new Error(response?.error || 'Scan failed');
    }

    await chrome.storage.local.set({ lastScanResult: response });

    const unique = response.stats?.unique || 0;
    const skipped = response.stats?.skipped || 0;
    const known = response.stats?.knownGlobally || 0;
    const total = response.stats?.totalFound || 0;

    renderProgress({
      phase: 'complete',
      percent: 100,
      captured: unique,
      skipped,
      detail: unique
        ? `Done — ${unique} locators ready (${known} matched global store)`
        : 'No locators found — open a normal website and refresh the page first'
    });

    if (!unique) {
      setStatus(
        total > 0
          ? `Scanned ${total} elements but none were usable. Try disabling "Cross-domain dedup" or refresh the page.`
          : 'No elements found. Make sure you are on a regular website (not chrome://) and reload the page after installing the extension.',
        true
      );
    } else {
      const parts = [`${unique} locators ready to copy`];
      if (skipped) parts.push(`${skipped} on-page duplicates skipped`);
      if (known) parts.push(`${known} already known from other locales`);
      setStatus(parts.join(' · '));
    }
    await updateStoreStats();
  } catch (error) {
    renderProgress({ phase: 'error', percent: 0, detail: error.message });
    setStatus(error.message, true);
  } finally {
    els.scanBtn.disabled = false;
    els.scanBtn.textContent = 'Scan Page';
  }
}

async function onOpenPanel() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id) {
    await chrome.sidePanel.open({ tabId: tab.id });
  }
}

async function onClearStore() {
  await clearFingerprintStore();
  setStatus('Cross-domain locator store cleared.');
  await updateStoreStats();
}

async function updateStoreStats() {
  const stats = await getFingerprintStats();
  els.clearStoreBtn.textContent = `Clear cross-domain locator store (${stats.total} stored across ${stats.domains} domains)`;
}
