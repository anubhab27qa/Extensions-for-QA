import { loadSettings, saveSettings, getFrameworkOptions } from '../src/shared/settings.js';
import { formatLocator, formatAll, formatPageObjectClass } from '../src/lib/frameworkFormatters.js';

const PHASE_LABELS = {
  preparing: 'Preparing',
  page: 'Scanning page',
  iframe: 'Scanning iframes',
  popups: 'Scanning popups',
  hidden_modal: 'Hidden modals',
  dedup: 'Deduplicating',
  complete: 'Complete',
  error: 'Error'
};

const els = {
  meta: document.getElementById('meta'),
  refreshBtn: document.getElementById('refreshBtn'),
  copyAllBtn: document.getElementById('copyAllBtn'),
  framework: document.getElementById('framework'),
  viewMode: document.getElementById('viewMode'),
  filterInput: document.getElementById('filterInput'),
  stats: document.getElementById('stats'),
  results: document.getElementById('results'),
  template: document.getElementById('locatorCardTemplate'),
  scanProgress: document.getElementById('scanProgress'),
  scanPhase: document.getElementById('scanPhase'),
  scanPercent: document.getElementById('scanPercent'),
  scanBar: document.getElementById('scanBar'),
  scanDetail: document.getElementById('scanDetail')
};

let scanResult = null;
let settings = await loadSettings();

init();

async function init() {
  renderFrameworks();
  els.framework.value = settings.frameworkId;
  await loadLastScan();

  const stored = await chrome.storage.local.get(['scanProgress']);
  if (stored.scanProgress) renderScanProgress(stored.scanProgress);

  els.refreshBtn.addEventListener('click', onRefresh);
  els.copyAllBtn.addEventListener('click', onCopyAll);
  els.framework.addEventListener('change', onFrameworkChange);
  els.viewMode.addEventListener('change', render);
  els.filterInput.addEventListener('input', render);
}

function renderFrameworks() {
  els.framework.innerHTML = getFrameworkOptions()
    .map((fw) => `<option value="${fw.id}">${fw.label}</option>`)
    .join('');
}

async function loadLastScan() {
  const stored = await chrome.storage.local.get(['lastScanResult']);
  scanResult = stored.lastScanResult || null;
  render();
}

async function onRefresh() {
  els.refreshBtn.disabled = true;
  els.refreshBtn.textContent = 'Scanning…';
  renderScanProgress({ phase: 'preparing', percent: 0, detail: 'Starting scan…' });

  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const response = await chrome.runtime.sendMessage({
    type: 'SCAN_ACTIVE_TAB',
    tabId: tab?.id,
    frameworkId: els.framework.value,
    className: settings.className,
    options: settings
  });

  els.refreshBtn.disabled = false;
  els.refreshBtn.textContent = 'Refresh';

  if (!response?.ok) {
    renderScanProgress({ phase: 'error', percent: 0, detail: response?.error || 'Scan failed' });
    els.meta.textContent = response?.error || 'Scan failed';
    return;
  }

  scanResult = response;
  await chrome.storage.local.set({ lastScanResult: response });
  renderScanProgress({
    phase: 'complete',
    percent: 100,
    detail: `Found ${response.stats?.unique || 0} unique locators`
  });
  render();
}

function renderScanProgress(progress) {
  if (!progress) return;

  const isActive = !['complete', 'error'].includes(progress.phase) || progress.percent < 100;
  els.scanProgress.classList.toggle('hidden', progress.phase === 'complete' && scanResult);

  els.scanPhase.textContent = PHASE_LABELS[progress.phase] || progress.phase || 'Scanning';
  els.scanPercent.textContent = `${progress.percent ?? 0}%`;
  els.scanBar.style.width = `${progress.percent ?? 0}%`;

  const eta = progress.etaSeconds == null
    ? ''
    : progress.etaSeconds <= 0
      ? ' · ETA <1s'
      : ` · ETA ~${progress.etaSeconds}s`;

  const parts = [
    progress.currentName ? `Capturing: ${progress.currentName}` : progress.detail,
    progress.processed != null ? `${progress.processed}/${progress.total || '?'} processed` : null,
    progress.captured != null ? `${progress.captured} captured` : null
  ].filter(Boolean);

  els.scanDetail.textContent = `${parts.join(' · ')}${eta}` || 'Scanning…';

  if (progress.phase === 'complete') {
    els.scanBar.style.background = '#16a34a';
    setTimeout(() => els.scanProgress.classList.add('hidden'), 4000);
  } else if (isActive) {
    els.scanProgress.classList.remove('hidden');
    els.scanBar.style.background = 'linear-gradient(90deg, #2563eb, #22c55e)';
  }
}

async function onFrameworkChange() {
  settings.frameworkId = els.framework.value;
  await saveSettings(settings);
  render();
}

function getFilteredLocators() {
  if (!scanResult?.locators) return [];
  const q = els.filterInput.value.trim().toLowerCase();
  if (!q) return scanResult.locators;

  return scanResult.locators.filter((locator) => {
    const haystack = [
      locator.name,
      locator.tag,
      locator.source,
      locator.bestStrategy,
      locator.text,
      JSON.stringify(locator.context || {})
    ].join(' ').toLowerCase();
    return haystack.includes(q);
  });
}

function render() {
  if (!scanResult) {
    els.meta.textContent = 'Run a scan from the extension popup.';
    els.stats.textContent = '';
    els.results.innerHTML = '<div class="empty">No scan results yet.</div>';
    return;
  }

  const locators = getFilteredLocators();
  const frameworkId = els.framework.value;

  els.meta.textContent = scanResult.stats?.pageUrl || 'Last scan';
  const known = scanResult.stats?.knownGlobally || 0;
  els.stats.textContent = `Showing ${locators.length} locators | ${scanResult.stats?.skipped || 0} on-page dupes | ${known} known from other locales | framework: ${frameworkId}`;

  if (els.viewMode.value === 'raw') {
    els.results.innerHTML = `<div class="raw-block"><pre>${escapeHtml(formatAll(locators, frameworkId))}</pre></div>`;
    return;
  }

  if (els.viewMode.value === 'class') {
    els.results.innerHTML = `<div class="raw-block"><pre>${escapeHtml(formatPageObjectClass(locators, frameworkId, settings.className))}</pre></div>`;
    return;
  }

  els.results.innerHTML = '';
  if (!locators.length) {
    els.results.innerHTML = '<div class="empty">No locators match your filter.</div>';
    return;
  }

  for (const locator of locators) {
    const node = els.template.content.cloneNode(true);
    node.querySelector('.locator-name').textContent = locator.name;
    node.querySelector('.locator-name').title = locator.context?.pageLabel || locator.text || locator.name;
    node.querySelector('.locator-meta').textContent = [
      locator.tag,
      locator.bestStrategy,
      locator.locatorQuality || (locator.isRelative ? 'relative' : 'positional'),
      locator.context?.anchor ? `anchor:${locator.context.anchor}` : null,
      locator.source,
      locator.knownGlobally ? `known:${locator.knownFromDomain}` : null,
      locator.context?.inModal ? 'modal' : null,
      locator.context?.inIframe ? `iframe:${locator.context.iframeName}` : null
    ].filter(Boolean).join(' | ');

    node.querySelector('.locator-code').textContent = formatLocator(locator, frameworkId);
    node.querySelector('.strategies').textContent = JSON.stringify(locator.strategies, null, 2);

    node.querySelector('.copy-btn').addEventListener('click', async () => {
      await navigator.clipboard.writeText(formatLocator(locator, frameworkId));
    });

    node.querySelector('.highlight-btn').addEventListener('click', async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) return;
      chrome.tabs.sendMessage(tab.id, { type: 'HIGHLIGHT_LOCATOR', locator });
    });

    els.results.appendChild(node);
  }
}

async function onCopyAll() {
  if (!scanResult) return;
  const locators = getFilteredLocators();
  const frameworkId = els.framework.value;
  let text = '';

  if (els.viewMode.value === 'class') {
    text = formatPageObjectClass(locators, frameworkId, settings.className);
  } else {
    text = formatAll(locators, frameworkId);
  }

  await navigator.clipboard.writeText(text);
  els.copyAllBtn.textContent = 'Copied!';
  setTimeout(() => {
    els.copyAllBtn.textContent = 'Copy All';
  }, 1200);
}

function escapeHtml(value) {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.scanProgress?.newValue) {
    renderScanProgress(changes.scanProgress.newValue);
  }
  if (area === 'local' && changes.lastScanResult) {
    scanResult = changes.lastScanResult.newValue;
    render();
  }
});
