import { FRAMEWORKS, LOCATOR_PRIORITY } from '../lib/constants.js';

export const DEFAULT_SETTINGS = {
  frameworkId: 'javaSeleniumPageFactory',
  priority: [...LOCATOR_PRIORITY],
  includeContainers: true,
  includeHidden: true,
  includeNested: true,
  autoOpenPopups: true,
  respectGlobalStore: true,
  className: 'PageLocators'
};

export async function loadSettings() {
  const result = await chrome.storage.sync.get(['settings']);
  return { ...DEFAULT_SETTINGS, ...(result.settings || {}) };
}

export async function saveSettings(settings) {
  await chrome.storage.sync.set({ settings });
}

export function getFrameworkOptions() {
  return Object.values(FRAMEWORKS);
}

export function getPriorityOptions() {
  return LOCATOR_PRIORITY.map((key) => ({
    key,
    label: key
      .replace(/([A-Z])/g, ' $1')
      .replace(/^./, (s) => s.toUpperCase())
      .replace('Relative Css', 'CSS (anchored relative)')
      .replace('Relative Xpath', 'XPath (anchored relative)')
      .replace('Data Test Id', 'data-testid')
      .replace('Data Test', 'data-test')
      .replace('Data Qa', 'data-qa')
      .replace('Data Cy', 'data-cy')
      .replace('Anchored Text Xpath', 'XPath (anchored visible text)')
      .replace('Xpath Text', 'XPath (visible text — language dependent)')
      .replace('Xpath', 'XPath (attribute-based)')
  }));
}
