let modulesPromise = null;
let isScanning = false;

function loadModules() {
  if (!modulesPromise) {
    modulesPromise = Promise.all([
      import(chrome.runtime.getURL('src/lib/scanner.js')),
      import(chrome.runtime.getURL('src/lib/frameworkFormatters.js')),
      import(chrome.runtime.getURL('src/lib/constants.js'))
    ]);
  }
  return modulesPromise;
}

function isTrustedSender(sender) {
  return !sender?.id || sender.id === chrome.runtime.id;
}

function sendProgress(state) {
  chrome.runtime.sendMessage({
    type: 'SCAN_PROGRESS',
    progress: state
  }).catch(() => {});
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'PING') {
    sendResponse({ ok: true, ready: true });
    return false;
  }

  if (message.type === 'SCAN_PAGE') {
    if (!isTrustedSender(sender)) {
      sendResponse({ ok: false, error: 'Unauthorized scan request' });
      return false;
    }

    if (isScanning) {
      sendResponse({ ok: false, error: 'Scan already in progress' });
      return false;
    }

    isScanning = true;
    sendProgress({ phase: 'preparing', percent: 0, detail: 'Starting scan…' });

    loadModules()
      .then(([{ scanPage }, { formatLocator, formatAll, formatPageObjectClass }, { FRAMEWORKS, LOCATOR_PRIORITY }]) => scanPage({
        ...(message.options || {}),
        onProgress: sendProgress
      }).then((result) => {
        const frameworkId = message.frameworkId || 'javaSeleniumPageFactory';
        const formatted = result.locators.map((locator) => ({
          ...locator,
          formatted: formatLocator(locator, frameworkId)
        }));

        const response = {
          ok: true,
          ...result,
          locators: formatted,
          formattedAll: formatAll(result.locators, frameworkId),
          pageObjectClass: formatPageObjectClass(result.locators, frameworkId, message.className || 'PageLocators'),
          frameworks: FRAMEWORKS,
          defaultPriority: LOCATOR_PRIORITY
        };

        chrome.runtime.sendMessage({ type: 'SCAN_COMPLETE', result: response }).catch(() => {});
        sendResponse(response);
      }))
      .catch((error) => {
        const err = { ok: false, error: error?.message || String(error) };
        chrome.runtime.sendMessage({ type: 'SCAN_COMPLETE', result: err }).catch(() => {});
        sendResponse(err);
      })
      .finally(() => {
        isScanning = false;
      });

    return true;
  }

  if (message.type === 'HIGHLIGHT_LOCATOR') {
    if (!isTrustedSender(sender)) {
      sendResponse({ ok: false, error: 'Unauthorized' });
      return false;
    }

    loadModules().then(() => {
      try {
        highlightElement(message);
        sendResponse({ ok: true });
      } catch (error) {
        sendResponse({ ok: false, error: error?.message || String(error) });
      }
    }).catch((error) => {
      sendResponse({ ok: false, error: error?.message || String(error) });
    });

    return true;
  }

  return false;
});

function highlightElement(message) {
  clearHighlights();
  const el = findElement(message.locator);
  if (!el) return;
  el.style.outline = '3px solid #ff6b35';
  el.style.outlineOffset = '2px';
  el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  el.dataset.tlpHighlighted = 'true';
}

function clearHighlights() {
  document.querySelectorAll('[data-tlp-highlighted="true"]').forEach((el) => {
    el.style.outline = '';
    el.style.outlineOffset = '';
    delete el.dataset.tlpHighlighted;
  });
}

function findElement(locator) {
  const strategies = locator.strategies || {};
  const attempts = [
    () => strategies.id && document.getElementById(strategies.id),
    () => strategies.name && document.querySelector(`[name="${CSS.escape(strategies.name)}"]`),
    () => strategies.css && document.querySelector(strategies.css),
    () => strategies.xpath && document.evaluate(strategies.xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue
  ];

  for (const attempt of attempts) {
    const el = attempt();
    if (el) return el;
  }
  return null;
}
